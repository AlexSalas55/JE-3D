Alex Salas, Oriol Bech

Control the skier and reach the finish line while navigating slopes and obstacles.
Controls:

W Key - Move forward (start skiing)
1 Key - Spawn level1 pos
2 Key - Spawn level2 pos
Arrow Left and Right, steer the skier.

Camera:
Arrow Up and Down move tilt the camera.
c key to enable free camera.
Camera follows automatically based on the slope implementation done but currently disabled.

Game Mechanics:
The skier accelerates based on the slope of the terrain.
Downhill slopes increase speed, while uphill slopes slow the skier down.
If the skier reaches finish line, game's over.
If the skier collides with obstacles, speed is reduced but still fine tuning the collision system.

Pending Stages and fine tuning the physics together with its collisions.